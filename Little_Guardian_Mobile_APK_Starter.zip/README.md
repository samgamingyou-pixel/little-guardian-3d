# Little Guardian 3D — Mobile APK starter

This is a **starter scaffold**, not the recovered previous project. It contains a small playable browser prototype and a GitHub Actions workflow intended to build a debug APK in the cloud.

## Build from mobile
1. Create a GitHub repository and upload/unzip these files into it.
2. Commit to the `main` branch.
3. Open the repository's **Actions** tab. Select **Build Android APK**, then **Run workflow** (or let the push trigger run).
4. When the workflow completes successfully, open its run, scroll to **Artifacts**, and download `Little-Guardian-debug-apk`.

The APK is an unsigned debug build for testing. Requires internet for Three.js CDN at runtime.
